#include <errno.h> 
#include <termios.h> 
#include <unistd.h>

#define ControlC 3

int ttysetchar(int fd, int flagname, char c)  {
   int error;
   struct termios term;
   
   if (tcgetattr(fd, &term) == -1) 
      return -1;
   term.c_cc[flagname] = (cc_t)c; 
   while (((error = tcsetattr(fd, TCSAFLUSH, &term)) == -1) &&
           (errno == EINTR)) ;
   return error;
}   

int main () {
  //  ttysetchar (STDIN_FILENO, VINTR, ControlC); // 3 is control C
  ttysetchar (STDIN_FILENO, VINTR, 0);
  while (1);
  // very important non-interruptible code
}
	    
