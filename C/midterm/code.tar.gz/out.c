#include <stdio.h>


int main () {
  int *x;
  
  fprintf (stdout, "oops");
  *x = 6;
}
