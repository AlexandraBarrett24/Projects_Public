#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>


#define MSGSIZE 16
char *msg1 = "hello, world #1";
char *msg2 = "hello, world #2";

void main () {
  char inbuf [MSGSIZE];
  int ends[2], j;
  pid_t pid;

  if (pipe(ends) == -1)  {
    perror ("pipe error");
    exit (1);
  }

#if 0
  // block case
  close (ends[1]);
  //  EOF
  if (read (ends[0], inbuf, MSGSIZE) == 0)
    fprintf (stderr, "EOF\n");
  exit (1);
#endif

  //#if 0
  //BROKEN
  close (ends[0]);
  write (ends[1], msg1, MSGSIZE);
  //#endif  

  pid = fork ();
  if (pid == 0) {// child reads from pipe

    close (ends[1]);
    read (ends[0], inbuf, MSGSIZE);
    fprintf (stderr, "%s\n", inbuf);
    read (ends[0], inbuf, MSGSIZE);
    fprintf (stderr, "%s\n", inbuf);
    close (ends[0]);

  }

  else if (pid > 0) {// parent writes to pipe
    close (ends[0]);

    write (ends[1], msg1, MSGSIZE);
    write (ends[1], msg2, MSGSIZE);

    close (ends[1]);

    wait (NULL);
  }


}
