#include <errno.h>
#include <stdlib.h>
#include <stdio.h>

void main () {
  char c;
  int *v;

  while (1) {
    c = getchar ();
    fprintf (stderr, "again\n");
    v = (int *)malloc (100000000);
  }
}
