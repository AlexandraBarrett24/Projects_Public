#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {
   int i;
   int age;

   if (argc < 4) {
      fprintf(stderr, "Usage: age weight name\n");
      return 1;
   }   

   printf("The argument array contains:\n");
   for (i = 0; i < 4; i++)
      printf("%d:%s\n", i, argv[i]);

   age = atoi (argv[1]);
   if (age < 18)
     fprintf (stderr, "Sorry %s, no youngsters in 4061!\n", argv[3]);
   return 0;
}
