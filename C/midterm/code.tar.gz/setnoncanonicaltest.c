#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

#define BUFSIZE 100
int setnoncanonical();
int gettermios(struct termios *termp);
int settermios(struct termios *termp);

int main() {
   char buf[BUFSIZE];
   struct termios term;
   int ret;

   fprintf(stderr,"Starting out in current mode (edit on the line)\n\n");
   ret = read(STDIN_FILENO,buf,BUFSIZE);
   fprintf(stderr,"Got %d characters: %.*s\n",ret,ret,buf);
   tcgetattr(STDIN_FILENO, &term);

   fprintf(stderr,"Setting non-canonical mode\n");
   setnoncanonical();
   ret = read(STDIN_FILENO,buf,BUFSIZE);
   fprintf(stderr,"\nGot %d characters: %.*s\n",ret,ret,buf);
   fprintf(stderr,"\nRestoring mode\n\n");
   tcsetattr(STDIN_FILENO, TCSAFLUSH, &term);
   ret = read(STDIN_FILENO,buf,BUFSIZE);
   fprintf(stderr,"\nGot %d characters: %.*s\n",ret,ret,buf);
   return 0;
}
