#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

void main () {
  int fd, n;
  char c, buf[100];

  read (0, &c, 1);
  fd = open ("foo", O_RDONLY);
  n = read (fd, buf, 10);
  buf[n] = '\0';
  printf ("buf=%s\n", buf);
}
