#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

int main(void) {
   pid_t childpid;
   int i = 5;

   childpid = fork();
   if (childpid == -1) {
      perror("Failed to fork");
      return 1;
   }
   if (childpid == 0) {                             /* child code */
     printf("#1: I am child %ld with i=%d\n", (long)getpid(), i);
     i = 7;
   }
   else {                                          /* parent code */
     i = 3;
     printf("#2: I am parent with %ld with i=%d\n", (long)getpid(), i);
     wait (NULL);
     printf("#3: I am parent with %ld with i=%d\n", (long)getpid(), i);
   }
   return 0;
}
