#include <stdio.h>

typedef struct S {
  int ss;    // 8 digits
  unsigned int phone; // 10 digits
} info_t;

#define MAX 1000000
info_t mine [MAX];

int main () {
  int i;
  FILE *binf, *asciif;

  for (i=0; i<MAX; i++) {
    mine[i].ss = (unsigned) 9373928739;
    mine[i].phone = 84830383;
  }
  
  binf = fopen ("f_bin.txt", "w");
  asciif = fopen ("f_ascii.txt", "w");

  for (i=0; i<MAX; i++) 
    fprintf (asciif, "%d%d\n", mine[i].ss, mine[i].phone);

  
  fwrite ((void*)mine, sizeof(info_t), MAX, binf);


  fclose (binf);
  fclose (asciif);
}

  
