#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>


int ttysetchar(int fd, int flagname, char c)  {
  int error;
  struct termios term;

  if (tcgetattr(fd, &term) == -1)
    return -1;
  term.c_cc[flagname] = (cc_t)c;
  while (((error = tcsetattr(fd, TCSAFLUSH, &term)) == -1) &&
	 (errno == EINTR)) ;
  return error;
}


void setnoncanonical(void) { 
   int error;
   int fd;
   int firsterrno = 0;
   struct termios term;
   char termbuf[L_ctermid];
             
   ctermid(termbuf);                          /* find the terminal name */
   fd = open (termbuf, O_RDONLY);             /* open the terminal */
   tcgetattr(fd, &term);                      /* get terminal attrs */
   term.c_lflag &= ~ICANON;                   /* set non-canonical mode */
   tcsetattr(fd, TCSAFLUSH, &term);
   ttysetchar(fd, VMIN, 3);                   /* wait for 3 characters only */
   ttysetchar(fd, VTIME, 0);
   close (fd);

}
