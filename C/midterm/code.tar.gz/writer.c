// writer.c
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

void main () {
  int fd;

  char c, buf[100] = "bbbbbbbbbb…";
  read (0, &c, 1);
  fd = open ("foo", O_WRONLY);
  write (fd, buf, 10);
  read (0, &c, 1);
  close (fd);
}
