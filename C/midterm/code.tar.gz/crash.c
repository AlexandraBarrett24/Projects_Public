#include <errno.h>
#include <stdlib.h>
#include <stdio.h>

void main () {

  int *b;

  *b = 10;
}
