#include <errno.h>
#include <stdlib.h>
#include <stdio.h>

void main () {

  while (1) {
    ;
  }
}
