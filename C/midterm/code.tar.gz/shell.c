#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main() {
  pid_t childpid = 0;
  char cmd [100];

  // BEWARE NO ERROR CHECKING OF SYS CALLS!!!
   while (1) {
     fprintf (stdout, "Enter command (no args allowed): ");
     scanf ("%s", cmd);

     //childpid = fork();
  
     if (childpid == 0) {                                      /* child code */
       execl(cmd, cmd, (char*) 0);
       perror("Child failed to execl the command");
       return 1;
     }
     wait (NULL);
   }
   return 0;    
}
